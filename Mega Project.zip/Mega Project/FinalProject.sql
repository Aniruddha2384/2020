create database FinalProject;
use FinalProject;
show tables;
select * from  	hibernate_sequence;
desc hibernate_sequence;
desc project_lead;
desc hire;
desc pool_hire;
desc hr;
desc project_manager_login;
desc responsetopl;
desc resquest_from_manger;

desc request_frompl; 

insert into project_manager_login values(1,"admin@gmail.com","9146431498","Admin","123");
insert into pool_hire values(1,"ravan@gmail.com","8-10","9632587410","java","ravan");
insert into pool_hire values(1,"Mayuridhle@gmail.om","8-10","9632587780","java","mayu");
insert into pool_hire values(2,"aniruddhadeshmukh@gmail.com","1-2","963258768","c++","ani");
insert into pool_hire values(3,"nakshtra@gmail.com","5-6","9632859647","AWT","niks");
insert into pool_hire values(4,"punam@gmail.com","9-10","9685587415","C","punam");
insert into pool_hire values(5,"Dimple@gmail.com","1-2","9952587410","Angular","dimple");
insert into pool_hire values(6,"yogesh@gmail.com","5-6","97302587410","React","yogesh");
insert into pool_hire values(7,"meghana@gmail.com","0-1","9569587410","java","meghana");
insert into pool_hire values(8,"mayank@gmail.com","2-3","9362587410","C","mayank");
insert into pool_hire values(9,"manoj@gmail.com","4-5","9623587410","python","manoj");
insert into pool_hire values(10,"meetali@gmail.com","3-4","9962587410","pstgrey","meetali");
insert into pool_hire values(11,"mahi@gmail.com","11-15","9632587410","Nodejs","mahi");
